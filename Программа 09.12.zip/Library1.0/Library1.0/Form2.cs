﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Library1._0
{
    public partial class FCards : Form
    {
        SqlConnection con = new SqlConnection("Server=WIN-76V4P6QRV5R\\SQLEXPRESS;" + "database=DB_library;" + "Integrated Security=True");
        SqlDataAdapter adap;
        DataSet ds;
        DataTable dt;

        public string NameCards;
        List<int> listReturnDate = new List<int>();
        public FCards()
        {
            InitializeComponent();
        }

        private void FCards_Load(object sender, EventArgs e)
        {
            ZeroObjForm();
            switch (NameCards)
            {
                case "CatalogCards":
                    {
                        lbListBooks.Visible = true;
                        adap = new SqlDataAdapter($"SELECT id,Название FROM Book", con);
                        dt = new DataTable();
                        adap.Fill(dt);
                        foreach (DataRow dr in dt.Rows)
                        {
                            lbListBooks.Items.Add($"{dr["id"]}\t{dr["Название"]}");
                        }
                        break;
                    }
                case "SubsCards":
                    {
                        lbListSubscribers.Visible = true;
                        CalculationIssuedBooks();
                        adap = new SqlDataAdapter($"SELECT id, Фамилия, Имя, Отчество FROM Subscriber", con);
                        dt = new DataTable();
                        adap.Fill(dt);
                        con.Close();
                        con.Open();
                        foreach (DataRow dr in dt.Rows)
                        {
                            SqlCommand command = new SqlCommand($"select max(Абонементный_номер) from Subscriber_Numbers " +
                                $"where Абонент= {dr["id"]}", con);
                            int subsNumber = (int)command.ExecuteScalar();
                            lbListSubscribers.Items.Add($"{subsNumber}\t{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.");
                        }
                        con.Close();
                        break;
                    }
            }
            
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        private void lbListBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            rtbCatalogCard.Visible = true;
            rtbCatalogCard.Text = "";
            string[] id_nameBook = lbListBooks.SelectedItem.ToString().Split('\t');
            adap = new SqlDataAdapter($"SELECT * FROM Book JOIN Avtor ON Book.Автор = Avtor.id " +
                $"JOIN Directory_publishers ON Directory_publishers.Произведение = Book.id where Book.id = {id_nameBook[0]}", con);
            dt = new DataTable();
            adap.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                string description = "";
                if (dr["Описание"].ToString() != "")
                {
                    description = $"- ({dr["Описание"]}).";
                }
                rtbCatalogCard.Text = $"{dr["Отдел"]}\n" +
                    $"{dr["Фамилия"].ToString().Trim()} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.\n\t" +
                    $"{dr["Название"]} : {dr["Жанр"]} / {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}. / " +
                    $"{dr["Фамилия"].ToString().Trim()}. - {dr["Место"].ToString()[0]}. : {dr["Издательство"]}, {dr["Год_издания"]}. " +
                    $"- {dr["Число_страниц"]} с. {description} - ISBN {dr["ISBN"].ToString().Trim()} : {dr["Цена"]}.00 р.";
            }
        }

        private void bSaveFile_Click(object sender, EventArgs e)
        {
            sfdCatalogCards.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            try
            {
                if (sfdCatalogCards.ShowDialog() == DialogResult.OK)
                {
                    switch (NameCards)
                    {
                        case "CatalogCards":
                            {
                                string filename = sfdCatalogCards.FileName;
                                System.IO.File.WriteAllText(filename, rtbCatalogCard.Text);
                                MessageBox.Show("Файл сохранен");
                                break;
                            }
                        case "SubsCards":
                            {
                                if (dgvSubsCard.Visible == true)
                                {

                                }
                                break;
                            }

                        default:
                            break;
                    }
                    
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Файл не сохранен");
            }
        }
        public void ZeroObjForm()
        {
            lbListBooks.Visible = false;
            rtbCatalogCard.Visible = false;
            lbListSubscribers.Visible = false;
            
        }
        public void CalculationIssuedBooks()
        {
            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers", con);
            ds = new DataSet(); // Создаем объект класса DataSet
            adap.Fill(ds, "Directory_readers");
            foreach (DataRow dr in ds.Tables["Directory_readers"].Rows)
            {
                string[] date = dr["Дата_возврата"].ToString().Split(' ');
                string[] retutnDate = date[0].Split('.');
                if (Convert.ToInt32(retutnDate[2]) > DateTime.Now.Year)
                {
                    listReturnDate.Add((int)dr["id"]);
                }
                else
                {
                    if (Convert.ToInt32(retutnDate[1]) > DateTime.Now.Month && Convert.ToInt32(retutnDate[2]) == DateTime.Now.Year)
                    {
                        listReturnDate.Add((int)dr["id"]);
                    }
                    else
                    {
                        if (Convert.ToInt32(retutnDate[0]) > DateTime.Now.Day && Convert.ToInt32(retutnDate[1]) == DateTime.Now.Month)
                        {
                            listReturnDate.Add((int)dr["id"]);
                        }
                    }
                }
            }
        }
        private void lbListSubscribers_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvSubsCard.Visible = true;
            dgvSubsCard.Rows.Clear();
            con.Open();
            SqlCommand command = new SqlCommand($"Select Абонент from Subscriber_numbers where Абонементный_номер = @SubsNum", con);
            command.Parameters.Add(new SqlParameter("@SubsNum", lbListSubscribers.SelectedItem.ToString().Split('\t')[0]));
            int idSubs = (int)command.ExecuteScalar();

            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers where Абонент = {idSubs}", con);
            ds = new DataSet(); // Создаем объект класса DataSet
            adap.Fill(ds, "Directory_readers");
            foreach (DataRow drDR in ds.Tables["Directory_readers"].Rows)
            {
                adap = new SqlDataAdapter($"SELECT * FROM Copy_book join Book on Book.id = Copy_book.Произведение " +
                    $"join Avtor on Book.Автор = Avtor.id where Copy_book.id = {drDR["Экземпляр"]}", con);
                adap.Fill(ds, $"Copy_book{drDR["id"]}");
                foreach (DataRow drCB in ds.Tables[$"Copy_book{drDR["id"]}"].Rows)
                {
                    string name_and_avtorBook = $"{drCB["Название"]}    " +
                        $"{drCB["Фамилия"]} {drCB["Имя"].ToString()[0]}.{drCB["Отчество"].ToString()[0]}.";
                    dgvSubsCard.Rows.Add(drDR["Дата_возврата"], drCB["Инвентарный_номер"], drCB["Отдел"], name_and_avtorBook);
                }
            }
            con.Close();
        }
    }
}
