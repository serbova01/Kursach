﻿namespace Library1._0
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.bSubscribers = new System.Windows.Forms.Button();
            this.bCatalog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bListBooks = new System.Windows.Forms.Button();
            this.gbWork = new System.Windows.Forms.GroupBox();
            this.gbSubscriber = new System.Windows.Forms.GroupBox();
            this.bOpenSubsCards = new System.Windows.Forms.Button();
            this.bOpenInsertSubs = new System.Windows.Forms.Button();
            this.dgvSubscribers = new System.Windows.Forms.DataGridView();
            this.idSubs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Firstname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Secondname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Middlename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateRegistration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Street = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.House = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apartment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbListBooks = new System.Windows.Forms.GroupBox();
            this.bChangeImage = new System.Windows.Forms.Button();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.bOpenPHistoryR_CB = new System.Windows.Forms.Button();
            this.pHistoryR_CB = new System.Windows.Forms.Panel();
            this.bClosePHistoryR_CB = new System.Windows.Forms.Button();
            this.dgvHistoryR_CB = new System.Windows.Forms.DataGridView();
            this.DRDateIssue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DRReturnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bInsertCB = new System.Windows.Forms.Button();
            this.rtbAddingInfCB = new System.Windows.Forms.RichTextBox();
            this.dgvCopyBook = new System.Windows.Forms.DataGridView();
            this.CBid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPInventaryNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPNameBook = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CPPublHouse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbCatalog = new System.Windows.Forms.GroupBox();
            this.bOpenForm2 = new System.Windows.Forms.Button();
            this.pHistoryR_B = new System.Windows.Forms.Panel();
            this.bClosePHistoryR_B = new System.Windows.Forms.Button();
            this.dgvHistoryR_B = new System.Windows.Forms.DataGridView();
            this.CPInvNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DRDate_issue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DRReturn_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SAbonent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bSaveCatalog = new System.Windows.Forms.Button();
            this.bHistoryR_B = new System.Windows.Forms.Button();
            this.dgvCatalog = new System.Windows.Forms.DataGridView();
            this.Bid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BGenre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BDepartment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvtorFIO = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opfImage = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.gbWork.SuspendLayout();
            this.gbSubscriber.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubscribers)).BeginInit();
            this.gbListBooks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.pHistoryR_CB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistoryR_CB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyBook)).BeginInit();
            this.gbCatalog.SuspendLayout();
            this.pHistoryR_B.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistoryR_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatalog)).BeginInit();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.bSubscribers);
            this.splitContainer1.Panel1.Controls.Add(this.bCatalog);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.bListBooks);
            this.splitContainer1.Panel1MinSize = 150;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gbWork);
            this.splitContainer1.Panel2MinSize = 1110;
            this.splitContainer1.Size = new System.Drawing.Size(1382, 553);
            this.splitContainer1.SplitterDistance = 237;
            this.splitContainer1.TabIndex = 1;
            // 
            // bSubscribers
            // 
            this.bSubscribers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bSubscribers.BackColor = System.Drawing.Color.DarkSlateGray;
            this.bSubscribers.FlatAppearance.BorderSize = 0;
            this.bSubscribers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSubscribers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bSubscribers.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bSubscribers.Location = new System.Drawing.Point(3, 169);
            this.bSubscribers.MinimumSize = new System.Drawing.Size(150, 50);
            this.bSubscribers.Name = "bSubscribers";
            this.bSubscribers.Size = new System.Drawing.Size(234, 50);
            this.bSubscribers.TabIndex = 3;
            this.bSubscribers.Text = "Абоненты";
            this.bSubscribers.UseVisualStyleBackColor = false;
            this.bSubscribers.Click += new System.EventHandler(this.bSubscribers_Click);
            // 
            // bCatalog
            // 
            this.bCatalog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bCatalog.BackColor = System.Drawing.Color.DarkSlateGray;
            this.bCatalog.FlatAppearance.BorderSize = 0;
            this.bCatalog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCatalog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bCatalog.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bCatalog.Location = new System.Drawing.Point(0, 114);
            this.bCatalog.MinimumSize = new System.Drawing.Size(150, 50);
            this.bCatalog.Name = "bCatalog";
            this.bCatalog.Size = new System.Drawing.Size(234, 50);
            this.bCatalog.TabIndex = 2;
            this.bCatalog.Text = "Каталог";
            this.bCatalog.UseVisualStyleBackColor = false;
            this.bCatalog.Click += new System.EventHandler(this.bCatalog_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(81, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Меню";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bListBooks
            // 
            this.bListBooks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bListBooks.BackColor = System.Drawing.Color.DarkSlateGray;
            this.bListBooks.FlatAppearance.BorderSize = 0;
            this.bListBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bListBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bListBooks.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bListBooks.Location = new System.Drawing.Point(0, 59);
            this.bListBooks.MinimumSize = new System.Drawing.Size(150, 50);
            this.bListBooks.Name = "bListBooks";
            this.bListBooks.Size = new System.Drawing.Size(234, 50);
            this.bListBooks.TabIndex = 0;
            this.bListBooks.Text = "Перечень книг";
            this.bListBooks.UseVisualStyleBackColor = false;
            this.bListBooks.Click += new System.EventHandler(this.bListBooks_Click);
            // 
            // gbWork
            // 
            this.gbWork.BackColor = System.Drawing.Color.CadetBlue;
            this.gbWork.Controls.Add(this.gbSubscriber);
            this.gbWork.Controls.Add(this.gbListBooks);
            this.gbWork.Controls.Add(this.gbCatalog);
            this.gbWork.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbWork.Font = new System.Drawing.Font("Stencil", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gbWork.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gbWork.Location = new System.Drawing.Point(0, 0);
            this.gbWork.Name = "gbWork";
            this.gbWork.Size = new System.Drawing.Size(1141, 553);
            this.gbWork.TabIndex = 0;
            this.gbWork.TabStop = false;
            // 
            // gbSubscriber
            // 
            this.gbSubscriber.Controls.Add(this.bOpenSubsCards);
            this.gbSubscriber.Controls.Add(this.bOpenInsertSubs);
            this.gbSubscriber.Controls.Add(this.dgvSubscribers);
            this.gbSubscriber.Location = new System.Drawing.Point(0, 10);
            this.gbSubscriber.Name = "gbSubscriber";
            this.gbSubscriber.Size = new System.Drawing.Size(1138, 543);
            this.gbSubscriber.TabIndex = 5;
            this.gbSubscriber.TabStop = false;
            this.gbSubscriber.Visible = false;
            // 
            // bOpenSubsCards
            // 
            this.bOpenSubsCards.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bOpenSubsCards.Location = new System.Drawing.Point(194, 479);
            this.bOpenSubsCards.Name = "bOpenSubsCards";
            this.bOpenSubsCards.Size = new System.Drawing.Size(116, 55);
            this.bOpenSubsCards.TabIndex = 12;
            this.bOpenSubsCards.Text = "Абонементные карточки";
            this.bOpenSubsCards.UseVisualStyleBackColor = true;
            this.bOpenSubsCards.Click += new System.EventHandler(this.bOpenSubsCards_Click);
            // 
            // bOpenInsertSubs
            // 
            this.bOpenInsertSubs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bOpenInsertSubs.Location = new System.Drawing.Point(43, 479);
            this.bOpenInsertSubs.Name = "bOpenInsertSubs";
            this.bOpenInsertSubs.Size = new System.Drawing.Size(93, 55);
            this.bOpenInsertSubs.TabIndex = 11;
            this.bOpenInsertSubs.Text = "Добавить абонента";
            this.bOpenInsertSubs.UseVisualStyleBackColor = true;
            this.bOpenInsertSubs.Click += new System.EventHandler(this.bOpenInsertSubs_Click);
            // 
            // dgvSubscribers
            // 
            this.dgvSubscribers.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvSubscribers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSubscribers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idSubs,
            this.Firstname,
            this.Secondname,
            this.Middlename,
            this.PhoneNumber,
            this.DateRegistration,
            this.Street,
            this.House,
            this.Apartment});
            this.dgvSubscribers.Location = new System.Drawing.Point(-1, 12);
            this.dgvSubscribers.Name = "dgvSubscribers";
            this.dgvSubscribers.RowHeadersWidth = 51;
            this.dgvSubscribers.RowTemplate.Height = 24;
            this.dgvSubscribers.Size = new System.Drawing.Size(1122, 442);
            this.dgvSubscribers.TabIndex = 0;
            // 
            // idSubs
            // 
            this.idSubs.HeaderText = "id";
            this.idSubs.MinimumWidth = 6;
            this.idSubs.Name = "idSubs";
            this.idSubs.Width = 70;
            // 
            // Firstname
            // 
            this.Firstname.HeaderText = "Фамилия";
            this.Firstname.MinimumWidth = 6;
            this.Firstname.Name = "Firstname";
            this.Firstname.Width = 150;
            // 
            // Secondname
            // 
            this.Secondname.HeaderText = "Имя";
            this.Secondname.MinimumWidth = 6;
            this.Secondname.Name = "Secondname";
            this.Secondname.Width = 140;
            // 
            // Middlename
            // 
            this.Middlename.HeaderText = "Отчество";
            this.Middlename.MinimumWidth = 6;
            this.Middlename.Name = "Middlename";
            this.Middlename.Width = 150;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.HeaderText = "Телефон";
            this.PhoneNumber.MinimumWidth = 6;
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Width = 110;
            // 
            // DateRegistration
            // 
            this.DateRegistration.HeaderText = "Дата регистрации";
            this.DateRegistration.MinimumWidth = 6;
            this.DateRegistration.Name = "DateRegistration";
            this.DateRegistration.Width = 125;
            // 
            // Street
            // 
            this.Street.HeaderText = "Улица";
            this.Street.MinimumWidth = 6;
            this.Street.Name = "Street";
            this.Street.Width = 150;
            // 
            // House
            // 
            this.House.HeaderText = "Дом";
            this.House.MinimumWidth = 6;
            this.House.Name = "House";
            this.House.Width = 70;
            // 
            // Apartment
            // 
            this.Apartment.HeaderText = "Квартира";
            this.Apartment.MinimumWidth = 6;
            this.Apartment.Name = "Apartment";
            this.Apartment.Width = 80;
            // 
            // gbListBooks
            // 
            this.gbListBooks.Controls.Add(this.bChangeImage);
            this.gbListBooks.Controls.Add(this.pbImage);
            this.gbListBooks.Controls.Add(this.bOpenPHistoryR_CB);
            this.gbListBooks.Controls.Add(this.pHistoryR_CB);
            this.gbListBooks.Controls.Add(this.bInsertCB);
            this.gbListBooks.Controls.Add(this.rtbAddingInfCB);
            this.gbListBooks.Controls.Add(this.dgvCopyBook);
            this.gbListBooks.Location = new System.Drawing.Point(2, 19);
            this.gbListBooks.Name = "gbListBooks";
            this.gbListBooks.Size = new System.Drawing.Size(1110, 531);
            this.gbListBooks.TabIndex = 4;
            this.gbListBooks.TabStop = false;
            // 
            // bChangeImage
            // 
            this.bChangeImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bChangeImage.Location = new System.Drawing.Point(996, 467);
            this.bChangeImage.Name = "bChangeImage";
            this.bChangeImage.Size = new System.Drawing.Size(93, 55);
            this.bChangeImage.TabIndex = 12;
            this.bChangeImage.Text = "Изменить обложку";
            this.bChangeImage.UseVisualStyleBackColor = true;
            this.bChangeImage.Click += new System.EventHandler(this.bChangeImage_Click);
            // 
            // pbImage
            // 
            this.pbImage.Location = new System.Drawing.Point(617, 243);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(334, 289);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage.TabIndex = 11;
            this.pbImage.TabStop = false;
            // 
            // bOpenPHistoryR_CB
            // 
            this.bOpenPHistoryR_CB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bOpenPHistoryR_CB.Location = new System.Drawing.Point(1004, 66);
            this.bOpenPHistoryR_CB.Name = "bOpenPHistoryR_CB";
            this.bOpenPHistoryR_CB.Size = new System.Drawing.Size(93, 55);
            this.bOpenPHistoryR_CB.TabIndex = 10;
            this.bOpenPHistoryR_CB.Text = "История читателей";
            this.bOpenPHistoryR_CB.UseVisualStyleBackColor = true;
            this.bOpenPHistoryR_CB.Click += new System.EventHandler(this.bOpenPHistoryR_CB_Click);
            // 
            // pHistoryR_CB
            // 
            this.pHistoryR_CB.Controls.Add(this.bClosePHistoryR_CB);
            this.pHistoryR_CB.Controls.Add(this.dgvHistoryR_CB);
            this.pHistoryR_CB.Location = new System.Drawing.Point(2, 353);
            this.pHistoryR_CB.Name = "pHistoryR_CB";
            this.pHistoryR_CB.Size = new System.Drawing.Size(537, 179);
            this.pHistoryR_CB.TabIndex = 9;
            this.pHistoryR_CB.Visible = false;
            // 
            // bClosePHistoryR_CB
            // 
            this.bClosePHistoryR_CB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bClosePHistoryR_CB.Location = new System.Drawing.Point(501, 4);
            this.bClosePHistoryR_CB.Name = "bClosePHistoryR_CB";
            this.bClosePHistoryR_CB.Size = new System.Drawing.Size(33, 30);
            this.bClosePHistoryR_CB.TabIndex = 10;
            this.bClosePHistoryR_CB.Text = "X";
            this.bClosePHistoryR_CB.UseVisualStyleBackColor = true;
            this.bClosePHistoryR_CB.Click += new System.EventHandler(this.bClosePHistoryR_CB_Click);
            // 
            // dgvHistoryR_CB
            // 
            this.dgvHistoryR_CB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHistoryR_CB.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvHistoryR_CB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistoryR_CB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DRDateIssue,
            this.DRReturnDate,
            this.SName});
            this.dgvHistoryR_CB.Location = new System.Drawing.Point(-1, 3);
            this.dgvHistoryR_CB.Name = "dgvHistoryR_CB";
            this.dgvHistoryR_CB.RowHeadersWidth = 51;
            this.dgvHistoryR_CB.RowTemplate.Height = 24;
            this.dgvHistoryR_CB.Size = new System.Drawing.Size(432, 173);
            this.dgvHistoryR_CB.TabIndex = 7;
            // 
            // DRDateIssue
            // 
            this.DRDateIssue.HeaderText = "Дата выдачи";
            this.DRDateIssue.MinimumWidth = 6;
            this.DRDateIssue.Name = "DRDateIssue";
            this.DRDateIssue.Width = 125;
            // 
            // DRReturnDate
            // 
            this.DRReturnDate.HeaderText = "Дата возврата";
            this.DRReturnDate.MinimumWidth = 6;
            this.DRReturnDate.Name = "DRReturnDate";
            this.DRReturnDate.Width = 125;
            // 
            // SName
            // 
            this.SName.HeaderText = "Абонент";
            this.SName.MinimumWidth = 6;
            this.SName.Name = "SName";
            this.SName.Width = 125;
            // 
            // bInsertCB
            // 
            this.bInsertCB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bInsertCB.Location = new System.Drawing.Point(1003, 16);
            this.bInsertCB.Name = "bInsertCB";
            this.bInsertCB.Size = new System.Drawing.Size(93, 33);
            this.bInsertCB.TabIndex = 8;
            this.bInsertCB.Text = "Привоз";
            this.bInsertCB.UseVisualStyleBackColor = true;
            this.bInsertCB.Click += new System.EventHandler(this.bInsertCB_Click);
            // 
            // rtbAddingInfCB
            // 
            this.rtbAddingInfCB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbAddingInfCB.Location = new System.Drawing.Point(558, 16);
            this.rtbAddingInfCB.Name = "rtbAddingInfCB";
            this.rtbAddingInfCB.Size = new System.Drawing.Size(432, 218);
            this.rtbAddingInfCB.TabIndex = 6;
            this.rtbAddingInfCB.Text = "      Здесь выводятся данные про книгу и издательство";
            // 
            // dgvCopyBook
            // 
            this.dgvCopyBook.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvCopyBook.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvCopyBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCopyBook.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CBid,
            this.CPInventaryNum,
            this.CPNameBook,
            this.CPPublHouse});
            this.dgvCopyBook.Location = new System.Drawing.Point(1, 19);
            this.dgvCopyBook.Name = "dgvCopyBook";
            this.dgvCopyBook.RowHeadersWidth = 51;
            this.dgvCopyBook.RowTemplate.Height = 24;
            this.dgvCopyBook.Size = new System.Drawing.Size(538, 506);
            this.dgvCopyBook.TabIndex = 5;
            this.dgvCopyBook.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCopyBook_CellClick);
            // 
            // CBid
            // 
            this.CBid.HeaderText = "id";
            this.CBid.MinimumWidth = 6;
            this.CBid.Name = "CBid";
            this.CBid.Width = 70;
            // 
            // CPInventaryNum
            // 
            this.CPInventaryNum.HeaderText = "Инвентарный номер";
            this.CPInventaryNum.MinimumWidth = 6;
            this.CPInventaryNum.Name = "CPInventaryNum";
            this.CPInventaryNum.Width = 125;
            // 
            // CPNameBook
            // 
            this.CPNameBook.HeaderText = "Произведение";
            this.CPNameBook.MinimumWidth = 6;
            this.CPNameBook.Name = "CPNameBook";
            this.CPNameBook.Width = 125;
            // 
            // CPPublHouse
            // 
            this.CPPublHouse.HeaderText = "Издательство";
            this.CPPublHouse.MinimumWidth = 6;
            this.CPPublHouse.Name = "CPPublHouse";
            this.CPPublHouse.Width = 150;
            // 
            // gbCatalog
            // 
            this.gbCatalog.Controls.Add(this.bOpenForm2);
            this.gbCatalog.Controls.Add(this.pHistoryR_B);
            this.gbCatalog.Controls.Add(this.bSaveCatalog);
            this.gbCatalog.Controls.Add(this.bHistoryR_B);
            this.gbCatalog.Controls.Add(this.dgvCatalog);
            this.gbCatalog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbCatalog.Location = new System.Drawing.Point(3, 19);
            this.gbCatalog.Name = "gbCatalog";
            this.gbCatalog.Size = new System.Drawing.Size(1135, 531);
            this.gbCatalog.TabIndex = 3;
            this.gbCatalog.TabStop = false;
            // 
            // bOpenForm2
            // 
            this.bOpenForm2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bOpenForm2.Location = new System.Drawing.Point(995, 85);
            this.bOpenForm2.Name = "bOpenForm2";
            this.bOpenForm2.Size = new System.Drawing.Size(109, 48);
            this.bOpenForm2.TabIndex = 13;
            this.bOpenForm2.Text = "Каталожные карточки";
            this.bOpenForm2.UseVisualStyleBackColor = true;
            this.bOpenForm2.Click += new System.EventHandler(this.bOpenForm2_Click);
            // 
            // pHistoryR_B
            // 
            this.pHistoryR_B.Controls.Add(this.bClosePHistoryR_B);
            this.pHistoryR_B.Controls.Add(this.dgvHistoryR_B);
            this.pHistoryR_B.Location = new System.Drawing.Point(1, 329);
            this.pHistoryR_B.Name = "pHistoryR_B";
            this.pHistoryR_B.Size = new System.Drawing.Size(988, 202);
            this.pHistoryR_B.TabIndex = 12;
            this.pHistoryR_B.Visible = false;
            // 
            // bClosePHistoryR_B
            // 
            this.bClosePHistoryR_B.Location = new System.Drawing.Point(762, 17);
            this.bClosePHistoryR_B.Name = "bClosePHistoryR_B";
            this.bClosePHistoryR_B.Size = new System.Drawing.Size(94, 39);
            this.bClosePHistoryR_B.TabIndex = 12;
            this.bClosePHistoryR_B.Text = "Закрыть";
            this.bClosePHistoryR_B.UseVisualStyleBackColor = true;
            this.bClosePHistoryR_B.Click += new System.EventHandler(this.bClosePHistoryR_B_Click);
            // 
            // dgvHistoryR_B
            // 
            this.dgvHistoryR_B.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvHistoryR_B.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistoryR_B.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CPInvNum,
            this.DRDate_issue,
            this.DRReturn_date,
            this.SAbonent});
            this.dgvHistoryR_B.Location = new System.Drawing.Point(3, 3);
            this.dgvHistoryR_B.Name = "dgvHistoryR_B";
            this.dgvHistoryR_B.RowHeadersWidth = 51;
            this.dgvHistoryR_B.RowTemplate.Height = 24;
            this.dgvHistoryR_B.Size = new System.Drawing.Size(606, 196);
            this.dgvHistoryR_B.TabIndex = 11;
            // 
            // CPInvNum
            // 
            this.CPInvNum.HeaderText = "Инвентарный номер";
            this.CPInvNum.MinimumWidth = 6;
            this.CPInvNum.Name = "CPInvNum";
            this.CPInvNum.Width = 125;
            // 
            // DRDate_issue
            // 
            this.DRDate_issue.HeaderText = "Дата выдачи";
            this.DRDate_issue.MinimumWidth = 6;
            this.DRDate_issue.Name = "DRDate_issue";
            this.DRDate_issue.Width = 125;
            // 
            // DRReturn_date
            // 
            this.DRReturn_date.HeaderText = "Дата возврата";
            this.DRReturn_date.MinimumWidth = 6;
            this.DRReturn_date.Name = "DRReturn_date";
            this.DRReturn_date.Width = 125;
            // 
            // SAbonent
            // 
            this.SAbonent.HeaderText = "Абонент";
            this.SAbonent.MinimumWidth = 6;
            this.SAbonent.Name = "SAbonent";
            this.SAbonent.Width = 170;
            // 
            // bSaveCatalog
            // 
            this.bSaveCatalog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bSaveCatalog.Location = new System.Drawing.Point(995, 150);
            this.bSaveCatalog.Name = "bSaveCatalog";
            this.bSaveCatalog.Size = new System.Drawing.Size(109, 48);
            this.bSaveCatalog.TabIndex = 10;
            this.bSaveCatalog.Text = "Сохранить изменения";
            this.bSaveCatalog.UseVisualStyleBackColor = true;
            this.bSaveCatalog.Visible = false;
            this.bSaveCatalog.Click += new System.EventHandler(this.bSaveCatalog_Click);
            // 
            // bHistoryR_B
            // 
            this.bHistoryR_B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bHistoryR_B.Location = new System.Drawing.Point(995, 22);
            this.bHistoryR_B.Name = "bHistoryR_B";
            this.bHistoryR_B.Size = new System.Drawing.Size(109, 48);
            this.bHistoryR_B.TabIndex = 9;
            this.bHistoryR_B.Text = "История читателей";
            this.bHistoryR_B.UseVisualStyleBackColor = true;
            this.bHistoryR_B.Click += new System.EventHandler(this.bHistoryR_B_Click);
            // 
            // dgvCatalog
            // 
            this.dgvCatalog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvCatalog.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvCatalog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCatalog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Bid,
            this.BName,
            this.BGenre,
            this.BDepartment,
            this.BDescription,
            this.AvtorFIO,
            this.Count});
            this.dgvCatalog.Location = new System.Drawing.Point(1, 22);
            this.dgvCatalog.MinimumSize = new System.Drawing.Size(875, 300);
            this.dgvCatalog.Name = "dgvCatalog";
            this.dgvCatalog.RowHeadersWidth = 51;
            this.dgvCatalog.RowTemplate.Height = 24;
            this.dgvCatalog.Size = new System.Drawing.Size(988, 500);
            this.dgvCatalog.TabIndex = 0;
            this.dgvCatalog.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalog_CellClick);
            this.dgvCatalog.CellToolTipTextChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalog_CellToolTipTextChanged);
            this.dgvCatalog.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCatalog_CellValueChanged);
            // 
            // Bid
            // 
            this.Bid.HeaderText = "id";
            this.Bid.MinimumWidth = 6;
            this.Bid.Name = "Bid";
            this.Bid.ReadOnly = true;
            this.Bid.Width = 70;
            // 
            // BName
            // 
            this.BName.HeaderText = "Произведение";
            this.BName.MinimumWidth = 6;
            this.BName.Name = "BName";
            this.BName.Width = 170;
            // 
            // BGenre
            // 
            this.BGenre.HeaderText = "Жанр";
            this.BGenre.MinimumWidth = 6;
            this.BGenre.Name = "BGenre";
            this.BGenre.Width = 120;
            // 
            // BDepartment
            // 
            this.BDepartment.HeaderText = "Отдел";
            this.BDepartment.MinimumWidth = 6;
            this.BDepartment.Name = "BDepartment";
            this.BDepartment.ReadOnly = true;
            this.BDepartment.Width = 80;
            // 
            // BDescription
            // 
            this.BDescription.HeaderText = "Краткое описание";
            this.BDescription.MinimumWidth = 6;
            this.BDescription.Name = "BDescription";
            this.BDescription.Width = 200;
            // 
            // AvtorFIO
            // 
            this.AvtorFIO.HeaderText = "Автор";
            this.AvtorFIO.MinimumWidth = 6;
            this.AvtorFIO.Name = "AvtorFIO";
            this.AvtorFIO.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.AvtorFIO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.AvtorFIO.Width = 170;
            // 
            // Count
            // 
            this.Count.HeaderText = "Количество";
            this.Count.MinimumWidth = 6;
            this.Count.Name = "Count";
            this.Count.Width = 125;
            // 
            // opfImage
            // 
            this.opfImage.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(1382, 553);
            this.Controls.Add(this.splitContainer1);
            this.MinimumSize = new System.Drawing.Size(1000, 500);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.gbWork.ResumeLayout(false);
            this.gbSubscriber.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubscribers)).EndInit();
            this.gbListBooks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.pHistoryR_CB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistoryR_CB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyBook)).EndInit();
            this.gbCatalog.ResumeLayout(false);
            this.pHistoryR_B.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistoryR_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCatalog)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bListBooks;
        private System.Windows.Forms.Button bSubscribers;
        private System.Windows.Forms.Button bCatalog;
        private System.Windows.Forms.GroupBox gbWork;
        private System.Windows.Forms.GroupBox gbCatalog;
        private System.Windows.Forms.GroupBox gbListBooks;
        private System.Windows.Forms.Button bInsertCB;
        private System.Windows.Forms.DataGridView dgvHistoryR_CB;
        private System.Windows.Forms.DataGridViewTextBoxColumn DRDateIssue;
        private System.Windows.Forms.DataGridViewTextBoxColumn DRReturnDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SName;
        private System.Windows.Forms.RichTextBox rtbAddingInfCB;
        private System.Windows.Forms.DataGridView dgvCopyBook;
        private System.Windows.Forms.DataGridViewTextBoxColumn CBid;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPInventaryNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPNameBook;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPPublHouse;
        private System.Windows.Forms.DataGridView dgvCatalog;
        private System.Windows.Forms.Button bSaveCatalog;
        private System.Windows.Forms.Button bHistoryR_B;
        private System.Windows.Forms.Button bClosePHistoryR_B;
        private System.Windows.Forms.DataGridView dgvHistoryR_B;
        public System.Windows.Forms.Panel pHistoryR_B;
        private System.Windows.Forms.DataGridViewTextBoxColumn CPInvNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn DRDate_issue;
        private System.Windows.Forms.DataGridViewTextBoxColumn DRReturn_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAbonent;
        private System.Windows.Forms.Button bOpenForm2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Bid;
        private System.Windows.Forms.DataGridViewTextBoxColumn BName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn BDepartment;
        private System.Windows.Forms.DataGridViewTextBoxColumn BDescription;
        private System.Windows.Forms.DataGridViewComboBoxColumn AvtorFIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Count;
        private System.Windows.Forms.Button bOpenPHistoryR_CB;
        private System.Windows.Forms.Panel pHistoryR_CB;
        private System.Windows.Forms.Button bClosePHistoryR_CB;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.Button bChangeImage;
        private System.Windows.Forms.OpenFileDialog opfImage;
        private System.Windows.Forms.GroupBox gbSubscriber;
        private System.Windows.Forms.Button bOpenSubsCards;
        private System.Windows.Forms.Button bOpenInsertSubs;
        private System.Windows.Forms.DataGridView dgvSubscribers;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSubs;
        private System.Windows.Forms.DataGridViewTextBoxColumn Firstname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Secondname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Middlename;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateRegistration;
        private System.Windows.Forms.DataGridViewTextBoxColumn Street;
        private System.Windows.Forms.DataGridViewTextBoxColumn House;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apartment;
    }
}

