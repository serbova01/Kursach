﻿namespace Library1._0
{
    partial class fInsert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pInsertCB = new System.Windows.Forms.Panel();
            this.tbPublHouse = new System.Windows.Forms.TextBox();
            this.tbNameBook = new System.Windows.Forms.TextBox();
            this.bInsertDP = new System.Windows.Forms.Button();
            this.bInsertB = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.nudNumCopies = new System.Windows.Forms.NumericUpDown();
            this.dgvCopy_book = new System.Windows.Forms.DataGridView();
            this.Book = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DirPublishers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumCopies = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bInsert = new System.Windows.Forms.Button();
            this.bDelete = new System.Windows.Forms.Button();
            this.bSave = new System.Windows.Forms.Button();
            this.pInsertB = new System.Windows.Forms.Panel();
            this.tbGenre = new System.Windows.Forms.TextBox();
            this.tbAvtor = new System.Windows.Forms.TextBox();
            this.bInsertAv = new System.Windows.Forms.Button();
            this.tbDepartment = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvBook = new System.Windows.Forms.DataGridView();
            this.NameBook = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Genre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Derpartment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Avtor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbDiscription = new System.Windows.Forms.TextBox();
            this.tbBook = new System.Windows.Forms.TextBox();
            this.pInsertPublH = new System.Windows.Forms.Panel();
            this.bInsertDPubl = new System.Windows.Forms.Button();
            this.bLoadImage = new System.Windows.Forms.Button();
            this.bClearTBpPH = new System.Windows.Forms.Button();
            this.pbImageBook = new System.Windows.Forms.PictureBox();
            this.tbPrice = new System.Windows.Forms.TextBox();
            this.tbBookPH = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tbISBN = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbNumPage = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbYearPubl = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbNamePublH = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbPlace = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ofdImageBook = new System.Windows.Forms.OpenFileDialog();
            this.pInsertAvtor = new System.Windows.Forms.Panel();
            this.bInsertAvtor = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tbMiddleNameAv = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbSecondNameAv = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbFirstNameAv = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pInsertCB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumCopies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopy_book)).BeginInit();
            this.pInsertB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBook)).BeginInit();
            this.pInsertPublH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageBook)).BeginInit();
            this.pInsertAvtor.SuspendLayout();
            this.SuspendLayout();
            // 
            // pInsertCB
            // 
            this.pInsertCB.Controls.Add(this.tbPublHouse);
            this.pInsertCB.Controls.Add(this.tbNameBook);
            this.pInsertCB.Controls.Add(this.bInsertDP);
            this.pInsertCB.Controls.Add(this.bInsertB);
            this.pInsertCB.Controls.Add(this.label3);
            this.pInsertCB.Controls.Add(this.nudNumCopies);
            this.pInsertCB.Controls.Add(this.dgvCopy_book);
            this.pInsertCB.Controls.Add(this.label2);
            this.pInsertCB.Controls.Add(this.label1);
            this.pInsertCB.Location = new System.Drawing.Point(58, 12);
            this.pInsertCB.Name = "pInsertCB";
            this.pInsertCB.Size = new System.Drawing.Size(765, 370);
            this.pInsertCB.TabIndex = 0;
            // 
            // tbPublHouse
            // 
            this.tbPublHouse.Location = new System.Drawing.Point(174, 91);
            this.tbPublHouse.Name = "tbPublHouse";
            this.tbPublHouse.Size = new System.Drawing.Size(178, 22);
            this.tbPublHouse.TabIndex = 15;
            // 
            // tbNameBook
            // 
            this.tbNameBook.Location = new System.Drawing.Point(174, 28);
            this.tbNameBook.Name = "tbNameBook";
            this.tbNameBook.Size = new System.Drawing.Size(178, 22);
            this.tbNameBook.TabIndex = 14;
            // 
            // bInsertDP
            // 
            this.bInsertDP.BackColor = System.Drawing.SystemColors.Window;
            this.bInsertDP.Location = new System.Drawing.Point(617, 77);
            this.bInsertDP.Name = "bInsertDP";
            this.bInsertDP.Size = new System.Drawing.Size(116, 64);
            this.bInsertDP.TabIndex = 13;
            this.bInsertDP.Text = "Добавить сведения об издании";
            this.bInsertDP.UseVisualStyleBackColor = false;
            this.bInsertDP.Click += new System.EventHandler(this.bInsertDP_Click);
            // 
            // bInsertB
            // 
            this.bInsertB.BackColor = System.Drawing.SystemColors.Window;
            this.bInsertB.Location = new System.Drawing.Point(461, 77);
            this.bInsertB.Name = "bInsertB";
            this.bInsertB.Size = new System.Drawing.Size(116, 50);
            this.bInsertB.TabIndex = 12;
            this.bInsertB.Text = "Добавить произведение";
            this.bInsertB.UseVisualStyleBackColor = false;
            this.bInsertB.Click += new System.EventHandler(this.bInsertB_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(467, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Количество экземпляров";
            // 
            // nudNumCopies
            // 
            this.nudNumCopies.Location = new System.Drawing.Point(662, 29);
            this.nudNumCopies.Name = "nudNumCopies";
            this.nudNumCopies.Size = new System.Drawing.Size(71, 22);
            this.nudNumCopies.TabIndex = 10;
            // 
            // dgvCopy_book
            // 
            this.dgvCopy_book.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvCopy_book.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCopy_book.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Book,
            this.DirPublishers,
            this.NumCopies});
            this.dgvCopy_book.Location = new System.Drawing.Point(3, 147);
            this.dgvCopy_book.Name = "dgvCopy_book";
            this.dgvCopy_book.RowHeadersWidth = 51;
            this.dgvCopy_book.RowTemplate.Height = 24;
            this.dgvCopy_book.Size = new System.Drawing.Size(445, 220);
            this.dgvCopy_book.TabIndex = 9;
            this.dgvCopy_book.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCopy_book_CellClick);
            // 
            // Book
            // 
            this.Book.HeaderText = "Произведение";
            this.Book.MinimumWidth = 6;
            this.Book.Name = "Book";
            this.Book.Width = 125;
            // 
            // DirPublishers
            // 
            this.DirPublishers.HeaderText = "Издательство";
            this.DirPublishers.MinimumWidth = 6;
            this.DirPublishers.Name = "DirPublishers";
            this.DirPublishers.Width = 125;
            // 
            // NumCopies
            // 
            this.NumCopies.HeaderText = "Количество";
            this.NumCopies.MinimumWidth = 6;
            this.NumCopies.Name = "NumCopies";
            this.NumCopies.Width = 125;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Издательство";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Произведение";
            // 
            // bInsert
            // 
            this.bInsert.BackColor = System.Drawing.SystemColors.Window;
            this.bInsert.Location = new System.Drawing.Point(58, 405);
            this.bInsert.Name = "bInsert";
            this.bInsert.Size = new System.Drawing.Size(97, 33);
            this.bInsert.TabIndex = 1;
            this.bInsert.Text = "Добавить";
            this.bInsert.UseVisualStyleBackColor = false;
            this.bInsert.Click += new System.EventHandler(this.bInsert_Click);
            // 
            // bDelete
            // 
            this.bDelete.BackColor = System.Drawing.SystemColors.Window;
            this.bDelete.Location = new System.Drawing.Point(197, 405);
            this.bDelete.Name = "bDelete";
            this.bDelete.Size = new System.Drawing.Size(97, 33);
            this.bDelete.TabIndex = 2;
            this.bDelete.Text = "Удалить";
            this.bDelete.UseVisualStyleBackColor = false;
            this.bDelete.Click += new System.EventHandler(this.bDelete_Click);
            // 
            // bSave
            // 
            this.bSave.BackColor = System.Drawing.SystemColors.Window;
            this.bSave.Location = new System.Drawing.Point(691, 405);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(97, 33);
            this.bSave.TabIndex = 3;
            this.bSave.Text = "Сохранить";
            this.bSave.UseVisualStyleBackColor = false;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // pInsertB
            // 
            this.pInsertB.Controls.Add(this.tbGenre);
            this.pInsertB.Controls.Add(this.tbAvtor);
            this.pInsertB.Controls.Add(this.bInsertAv);
            this.pInsertB.Controls.Add(this.tbDepartment);
            this.pInsertB.Controls.Add(this.label6);
            this.pInsertB.Controls.Add(this.label5);
            this.pInsertB.Controls.Add(this.dgvBook);
            this.pInsertB.Controls.Add(this.label8);
            this.pInsertB.Controls.Add(this.label7);
            this.pInsertB.Controls.Add(this.label4);
            this.pInsertB.Controls.Add(this.tbDiscription);
            this.pInsertB.Controls.Add(this.tbBook);
            this.pInsertB.Location = new System.Drawing.Point(35, 15);
            this.pInsertB.Name = "pInsertB";
            this.pInsertB.Size = new System.Drawing.Size(811, 384);
            this.pInsertB.TabIndex = 4;
            // 
            // tbGenre
            // 
            this.tbGenre.Location = new System.Drawing.Point(501, 24);
            this.tbGenre.Name = "tbGenre";
            this.tbGenre.Size = new System.Drawing.Size(121, 22);
            this.tbGenre.TabIndex = 17;
            this.tbGenre.TextChanged += new System.EventHandler(this.tbGenre_TextChanged);
            // 
            // tbAvtor
            // 
            this.tbAvtor.Location = new System.Drawing.Point(501, 118);
            this.tbAvtor.Name = "tbAvtor";
            this.tbAvtor.Size = new System.Drawing.Size(121, 22);
            this.tbAvtor.TabIndex = 16;
            // 
            // bInsertAv
            // 
            this.bInsertAv.BackColor = System.Drawing.SystemColors.Window;
            this.bInsertAv.Location = new System.Drawing.Point(642, 114);
            this.bInsertAv.Name = "bInsertAv";
            this.bInsertAv.Size = new System.Drawing.Size(31, 30);
            this.bInsertAv.TabIndex = 5;
            this.bInsertAv.Text = " +";
            this.bInsertAv.UseVisualStyleBackColor = false;
            this.bInsertAv.Click += new System.EventHandler(this.bInsertAv_Click);
            // 
            // tbDepartment
            // 
            this.tbDepartment.Location = new System.Drawing.Point(501, 72);
            this.tbDepartment.Name = "tbDepartment";
            this.tbDepartment.ReadOnly = true;
            this.tbDepartment.Size = new System.Drawing.Size(100, 22);
            this.tbDepartment.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(383, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Отдел";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(383, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Жанр";
            // 
            // dgvBook
            // 
            this.dgvBook.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBook.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameBook,
            this.Genre,
            this.Derpartment,
            this.Description,
            this.Avtor});
            this.dgvBook.Location = new System.Drawing.Point(3, 176);
            this.dgvBook.Name = "dgvBook";
            this.dgvBook.RowHeadersWidth = 51;
            this.dgvBook.RowTemplate.Height = 24;
            this.dgvBook.Size = new System.Drawing.Size(783, 191);
            this.dgvBook.TabIndex = 11;
            this.dgvBook.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBook_CellClick);
            // 
            // NameBook
            // 
            this.NameBook.HeaderText = "Произведение";
            this.NameBook.MinimumWidth = 6;
            this.NameBook.Name = "NameBook";
            this.NameBook.Width = 150;
            // 
            // Genre
            // 
            this.Genre.HeaderText = "Жанр";
            this.Genre.MinimumWidth = 6;
            this.Genre.Name = "Genre";
            this.Genre.Width = 125;
            // 
            // Derpartment
            // 
            this.Derpartment.HeaderText = "Отдел";
            this.Derpartment.MinimumWidth = 6;
            this.Derpartment.Name = "Derpartment";
            this.Derpartment.Width = 80;
            // 
            // Description
            // 
            this.Description.HeaderText = "Описание";
            this.Description.MinimumWidth = 6;
            this.Description.Name = "Description";
            this.Description.Width = 170;
            // 
            // Avtor
            // 
            this.Avtor.HeaderText = "Автор";
            this.Avtor.MinimumWidth = 6;
            this.Avtor.Name = "Avtor";
            this.Avtor.Width = 200;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(383, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "Автор";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 17);
            this.label7.TabIndex = 8;
            this.label7.Text = "Краткое описание";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Произведение";
            // 
            // tbDiscription
            // 
            this.tbDiscription.Location = new System.Drawing.Point(144, 74);
            this.tbDiscription.Multiline = true;
            this.tbDiscription.Name = "tbDiscription";
            this.tbDiscription.Size = new System.Drawing.Size(223, 66);
            this.tbDiscription.TabIndex = 1;
            // 
            // tbBook
            // 
            this.tbBook.Location = new System.Drawing.Point(144, 22);
            this.tbBook.Name = "tbBook";
            this.tbBook.Size = new System.Drawing.Size(193, 22);
            this.tbBook.TabIndex = 0;
            // 
            // pInsertPublH
            // 
            this.pInsertPublH.Controls.Add(this.bInsertDPubl);
            this.pInsertPublH.Controls.Add(this.bLoadImage);
            this.pInsertPublH.Controls.Add(this.bClearTBpPH);
            this.pInsertPublH.Controls.Add(this.pbImageBook);
            this.pInsertPublH.Controls.Add(this.tbPrice);
            this.pInsertPublH.Controls.Add(this.tbBookPH);
            this.pInsertPublH.Controls.Add(this.label15);
            this.pInsertPublH.Controls.Add(this.label16);
            this.pInsertPublH.Controls.Add(this.tbISBN);
            this.pInsertPublH.Controls.Add(this.label17);
            this.pInsertPublH.Controls.Add(this.label12);
            this.pInsertPublH.Controls.Add(this.tbNumPage);
            this.pInsertPublH.Controls.Add(this.label13);
            this.pInsertPublH.Controls.Add(this.tbYearPubl);
            this.pInsertPublH.Controls.Add(this.label11);
            this.pInsertPublH.Controls.Add(this.tbNamePublH);
            this.pInsertPublH.Controls.Add(this.label10);
            this.pInsertPublH.Controls.Add(this.tbPlace);
            this.pInsertPublH.Controls.Add(this.label9);
            this.pInsertPublH.Location = new System.Drawing.Point(35, 12);
            this.pInsertPublH.Name = "pInsertPublH";
            this.pInsertPublH.Size = new System.Drawing.Size(811, 433);
            this.pInsertPublH.TabIndex = 16;
            // 
            // bInsertDPubl
            // 
            this.bInsertDPubl.BackColor = System.Drawing.SystemColors.Window;
            this.bInsertDPubl.Location = new System.Drawing.Point(559, 390);
            this.bInsertDPubl.Name = "bInsertDPubl";
            this.bInsertDPubl.Size = new System.Drawing.Size(97, 33);
            this.bInsertDPubl.TabIndex = 22;
            this.bInsertDPubl.Text = "Добавить";
            this.bInsertDPubl.UseVisualStyleBackColor = false;
            this.bInsertDPubl.Click += new System.EventHandler(this.bInsertDPubl_Click);
            // 
            // bLoadImage
            // 
            this.bLoadImage.BackColor = System.Drawing.SystemColors.Window;
            this.bLoadImage.Location = new System.Drawing.Point(13, 146);
            this.bLoadImage.Name = "bLoadImage";
            this.bLoadImage.Size = new System.Drawing.Size(107, 43);
            this.bLoadImage.TabIndex = 20;
            this.bLoadImage.Text = "Загрузить обложку";
            this.bLoadImage.UseVisualStyleBackColor = false;
            this.bLoadImage.Click += new System.EventHandler(this.bLoadImage_Click);
            // 
            // bClearTBpPH
            // 
            this.bClearTBpPH.BackColor = System.Drawing.SystemColors.Window;
            this.bClearTBpPH.Location = new System.Drawing.Point(678, 390);
            this.bClearTBpPH.Name = "bClearTBpPH";
            this.bClearTBpPH.Size = new System.Drawing.Size(97, 33);
            this.bClearTBpPH.TabIndex = 17;
            this.bClearTBpPH.Text = "Очистить";
            this.bClearTBpPH.UseVisualStyleBackColor = false;
            this.bClearTBpPH.Click += new System.EventHandler(this.bClearTBpPH_Click);
            // 
            // pbImageBook
            // 
            this.pbImageBook.Location = new System.Drawing.Point(133, 119);
            this.pbImageBook.Name = "pbImageBook";
            this.pbImageBook.Size = new System.Drawing.Size(277, 251);
            this.pbImageBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImageBook.TabIndex = 19;
            this.pbImageBook.TabStop = false;
            // 
            // tbPrice
            // 
            this.tbPrice.Location = new System.Drawing.Point(583, 69);
            this.tbPrice.Name = "tbPrice";
            this.tbPrice.Size = new System.Drawing.Size(102, 22);
            this.tbPrice.TabIndex = 18;
            // 
            // tbBookPH
            // 
            this.tbBookPH.Location = new System.Drawing.Point(583, 194);
            this.tbBookPH.Name = "tbBookPH";
            this.tbBookPH.ReadOnly = true;
            this.tbBookPH.Size = new System.Drawing.Size(192, 22);
            this.tbBookPH.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(458, 197);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 17);
            this.label15.TabIndex = 16;
            this.label15.Text = "Произведение";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(458, 72);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 17);
            this.label16.TabIndex = 14;
            this.label16.Text = "Цена";
            // 
            // tbISBN
            // 
            this.tbISBN.Location = new System.Drawing.Point(583, 26);
            this.tbISBN.Name = "tbISBN";
            this.tbISBN.Size = new System.Drawing.Size(123, 22);
            this.tbISBN.TabIndex = 13;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(458, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 17);
            this.label17.TabIndex = 12;
            this.label17.Text = "ISBN";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "Обложка";
            // 
            // tbNumPage
            // 
            this.tbNumPage.Location = new System.Drawing.Point(583, 115);
            this.tbNumPage.Name = "tbNumPage";
            this.tbNumPage.Size = new System.Drawing.Size(73, 22);
            this.tbNumPage.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(458, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 17);
            this.label13.TabIndex = 8;
            this.label13.Text = "Число страниц";
            // 
            // tbYearPubl
            // 
            this.tbYearPubl.Location = new System.Drawing.Point(583, 156);
            this.tbYearPubl.Name = "tbYearPubl";
            this.tbYearPubl.Size = new System.Drawing.Size(100, 22);
            this.tbYearPubl.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(458, 156);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 17);
            this.label11.TabIndex = 4;
            this.label11.Text = "Год издания";
            // 
            // tbNamePublH
            // 
            this.tbNamePublH.Location = new System.Drawing.Point(133, 25);
            this.tbNamePublH.Name = "tbNamePublH";
            this.tbNamePublH.Size = new System.Drawing.Size(186, 22);
            this.tbNamePublH.TabIndex = 3;
            this.tbNamePublH.TextChanged += new System.EventHandler(this.tbNamePublH_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "Издательство";
            // 
            // tbPlace
            // 
            this.tbPlace.Location = new System.Drawing.Point(133, 69);
            this.tbPlace.Name = "tbPlace";
            this.tbPlace.Size = new System.Drawing.Size(100, 22);
            this.tbPlace.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Место";
            // 
            // ofdImageBook
            // 
            this.ofdImageBook.FileName = "openFileDialog1";
            // 
            // pInsertAvtor
            // 
            this.pInsertAvtor.Controls.Add(this.bInsertAvtor);
            this.pInsertAvtor.Controls.Add(this.button2);
            this.pInsertAvtor.Controls.Add(this.tbMiddleNameAv);
            this.pInsertAvtor.Controls.Add(this.label19);
            this.pInsertAvtor.Controls.Add(this.tbSecondNameAv);
            this.pInsertAvtor.Controls.Add(this.label18);
            this.pInsertAvtor.Controls.Add(this.tbFirstNameAv);
            this.pInsertAvtor.Controls.Add(this.label14);
            this.pInsertAvtor.Location = new System.Drawing.Point(35, 12);
            this.pInsertAvtor.Name = "pInsertAvtor";
            this.pInsertAvtor.Size = new System.Drawing.Size(811, 433);
            this.pInsertAvtor.TabIndex = 21;
            this.pInsertAvtor.Visible = false;
            // 
            // bInsertAvtor
            // 
            this.bInsertAvtor.BackColor = System.Drawing.SystemColors.Window;
            this.bInsertAvtor.Location = new System.Drawing.Point(575, 376);
            this.bInsertAvtor.Name = "bInsertAvtor";
            this.bInsertAvtor.Size = new System.Drawing.Size(97, 33);
            this.bInsertAvtor.TabIndex = 24;
            this.bInsertAvtor.Text = "Добавить";
            this.bInsertAvtor.UseVisualStyleBackColor = false;
            this.bInsertAvtor.Click += new System.EventHandler(this.bInsertAvtor_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(694, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 33);
            this.button2.TabIndex = 23;
            this.button2.Text = "Очистить";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // tbMiddleNameAv
            // 
            this.tbMiddleNameAv.Location = new System.Drawing.Point(330, 191);
            this.tbMiddleNameAv.Name = "tbMiddleNameAv";
            this.tbMiddleNameAv.Size = new System.Drawing.Size(219, 22);
            this.tbMiddleNameAv.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(242, 194);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 17);
            this.label19.TabIndex = 4;
            this.label19.Text = "Отчество";
            // 
            // tbSecondNameAv
            // 
            this.tbSecondNameAv.Location = new System.Drawing.Point(330, 144);
            this.tbSecondNameAv.Name = "tbSecondNameAv";
            this.tbSecondNameAv.Size = new System.Drawing.Size(219, 22);
            this.tbSecondNameAv.TabIndex = 3;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(242, 149);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "Имя";
            // 
            // tbFirstNameAv
            // 
            this.tbFirstNameAv.Location = new System.Drawing.Point(330, 98);
            this.tbFirstNameAv.Name = "tbFirstNameAv";
            this.tbFirstNameAv.Size = new System.Drawing.Size(219, 22);
            this.tbFirstNameAv.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(242, 103);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "Фамилия";
            // 
            // fInsert
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(882, 453);
            this.Controls.Add(this.pInsertAvtor);
            this.Controls.Add(this.pInsertPublH);
            this.Controls.Add(this.pInsertB);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.bDelete);
            this.Controls.Add(this.bInsert);
            this.Controls.Add(this.pInsertCB);
            this.MaximumSize = new System.Drawing.Size(900, 500);
            this.MinimumSize = new System.Drawing.Size(900, 500);
            this.Name = "fInsert";
            this.Text = "Insert";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Insert_Load);
            this.pInsertCB.ResumeLayout(false);
            this.pInsertCB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumCopies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopy_book)).EndInit();
            this.pInsertB.ResumeLayout(false);
            this.pInsertB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBook)).EndInit();
            this.pInsertPublH.ResumeLayout(false);
            this.pInsertPublH.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageBook)).EndInit();
            this.pInsertAvtor.ResumeLayout(false);
            this.pInsertAvtor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pInsertCB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvCopy_book;
        private System.Windows.Forms.Button bInsert;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudNumCopies;
        private System.Windows.Forms.Button bDelete;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.DataGridViewTextBoxColumn Book;
        private System.Windows.Forms.DataGridViewTextBoxColumn DirPublishers;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumCopies;
        private System.Windows.Forms.Button bInsertDP;
        private System.Windows.Forms.Button bInsertB;
        private System.Windows.Forms.Panel pInsertB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbDiscription;
        private System.Windows.Forms.TextBox tbBook;
        private System.Windows.Forms.DataGridView dgvBook;
        private System.Windows.Forms.Button bInsertAv;
        private System.Windows.Forms.TextBox tbDepartment;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNameBook;
        private System.Windows.Forms.TextBox tbPublHouse;
        private System.Windows.Forms.TextBox tbAvtor;
        private System.Windows.Forms.TextBox tbGenre;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameBook;
        private System.Windows.Forms.DataGridViewTextBoxColumn Genre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Derpartment;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Avtor;
        private System.Windows.Forms.Panel pInsertPublH;
        private System.Windows.Forms.TextBox tbBookPH;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbISBN;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbNumPage;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbYearPubl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbNamePublH;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbPlace;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pbImageBook;
        private System.Windows.Forms.TextBox tbPrice;
        private System.Windows.Forms.Button bClearTBpPH;
        private System.Windows.Forms.Button bLoadImage;
        private System.Windows.Forms.OpenFileDialog ofdImageBook;
        private System.Windows.Forms.Button bInsertDPubl;
        private System.Windows.Forms.Panel pInsertAvtor;
        private System.Windows.Forms.TextBox tbMiddleNameAv;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbSecondNameAv;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbFirstNameAv;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button bInsertAvtor;
        private System.Windows.Forms.Button button2;
    }
}