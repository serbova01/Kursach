﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library1._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Server=WIN-76V4P6QRV5R\\SQLEXPRESS;" + "database=DB_library;" + "Integrated Security=True");
        SqlDataAdapter adap;
        DataSet ds;
        DataTable dt;
        List<int> listReturnDate = new List<int>();

        FCards cards;

        string id_CopyBook;
        string id_Book;
        string id_DirPubl;
        private void Form1_Load(object sender, EventArgs e)
        {
            ZeroGb();
            CalculationIssuedBooks();
            PresentJoinData("Copy_book-Book-Avtor-Directory_publishers");
            PresentJoinData("Book-Avtor");
            //PresentData("Dir_Readers", " ");
            //PresentData("Subscriber", " ");
        }
        public void CalculationIssuedBooks()
        {
            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers", con);
            ds = new DataSet(); // Создаем объект класса DataSet
            adap.Fill(ds, "Directory_readers");
            foreach (DataRow dr in ds.Tables["Directory_readers"].Rows)
            {
                string[] date = dr["Дата_возврата"].ToString().Split(' ');
                string[] retutnDate = date[0].Split('.');
                if (Convert.ToInt32(retutnDate[2]) > DateTime.Now.Year)
                {
                    listReturnDate.Add((int)dr["id"]);
                }
                else
                {
                    if (Convert.ToInt32(retutnDate[1]) > DateTime.Now.Month && Convert.ToInt32(retutnDate[2]) == DateTime.Now.Year)
                    {
                        listReturnDate.Add((int)dr["id"]);
                    }
                    else
                    {
                        if (Convert.ToInt32(retutnDate[0]) > DateTime.Now.Day && Convert.ToInt32(retutnDate[1]) == DateTime.Now.Month)
                        {
                            listReturnDate.Add((int)dr["id"]);
                        }
                    }
                }
            }
        }
        public void PresentJoinData(string namesJoinData)
        {
            switch (namesJoinData)
            {
                case "Copy_book-Book-Avtor-Directory_publishers":
                    {
                        dgvCopyBook.Rows.Clear();
                        adap = new SqlDataAdapter($"SELECT * FROM Copy_book JOIN Book ON Copy_book.Произведение = Book.id " +
                            $"JOIN Avtor ON Book.Автор = Avtor.id JOIN Directory_publishers ON" +
                            $" Copy_book.Издательство = Directory_publishers.id", con);
                        ds = new DataSet(); // Создаем объект класса DataSet
                        adap.Fill(ds, "Copy_book");
                        foreach (DataRow dr in ds.Tables["Copy_book"].Rows)
                        {
                            dgvCopyBook.Rows.Add(dr["id"], dr["Инвентарный_номер"], dr["Название"], dr["Издательство1"]);
                        }
                        con.Close();
                        break;
                    }
                case "Book-Avtor":
                    {
                        dgvCatalog.Rows.Clear();
                        con.Open();
                        adap = new SqlDataAdapter($"SELECT * FROM Book JOIN Avtor ON Book.Автор = Avtor.id", con);
                        ds = new DataSet(); // Создаем объект класса DataSet
                        adap.Fill(ds, "Book");
                        adap = new SqlDataAdapter($"SELECT * FROM Avtor", con);
                        adap.Fill(ds, "Avtor");
                        foreach (DataRow dr in ds.Tables["Book"].Rows)
                        {
                            SqlCommand command = new SqlCommand($"select count(id) from Copy_book where Произведение = {dr["id"]}", con);
                            int count = (int)command.ExecuteScalar();
                            string nameAvtor = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                            dgvCatalog.Rows.Add(dr["id"], dr["Название"], dr["Жанр"], dr["Отдел"], dr["Описание"], nameAvtor, count);
                        }
                        for (int i = 0; i < dgvCatalog.Rows.Count - 1; i++)
                        {
                            foreach (DataRow dr in ds.Tables["Avtor"].Rows)
                            {
                                string nameAvtor = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                                (dgvCatalog.Rows[i].Cells[5] as DataGridViewComboBoxCell).Items.Add(nameAvtor);
                            }
                        }
                        con.Close();
                        break;
                    }
                case "Subscriber":
                    {
                        dgvSubscribers.Rows.Clear();
                        adap = new SqlDataAdapter($"SELECT * FROM Subscriber", con);
                        ds = new DataSet(); // Создаем объект класса DataSet
                        adap.Fill(ds, "Subscriber");
                        con.Close();
                        con.Open();
                        foreach (DataRow dr in ds.Tables["Subscriber"].Rows)
                        {
                            SqlCommand command = new SqlCommand($"select max(Абонементный_номер) from Subscriber_Numbers " +
                                $"where Абонент= {dr["id"]}", con);
                            int subsNumber = (int)command.ExecuteScalar();
                            dgvSubscribers.Rows.Add(subsNumber, dr["Фамилия"], dr["Имя"], dr["Отчество"], dr["Телефон"], 
                                dr["Дата_регистрации"], dr["Улица"], dr["Дом"], dr["Квартира"]);
                        }
                        con.Close();
                        break;
                    }
            }
        }

        private void bListBooks_Click(object sender, EventArgs e)
        {
            ZeroGb();
            gbListBooks.Visible = true;
        }
        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            Image returnImage;
            try
            {
                MemoryStream ms = new MemoryStream(byteArrayIn, 0, byteArrayIn.Length);
                ms.Write(byteArrayIn, 0, byteArrayIn.Length);
                returnImage = Image.FromStream(ms, true);//Exception occurs here
                return returnImage;
            }
            catch { return null; }
        }
        public static byte[] imageToByteArray(Image imageIn)
        {
            try
            {
                MemoryStream ms = new MemoryStream();
                imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Gif);
                return ms.ToArray();
            }
            catch { return null; }
            
        }
        public void PresentData(string nameData, string addingParameter)
        {
            switch (nameData)
            {
                case "Dir_ReadersCB":
                    {
                        dgvHistoryR_CB.Rows.Clear();
                        
                            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers JOIN Subscriber ON " +
                                $"Directory_readers.Абонент = Subscriber.id where Directory_readers.Экземпляр = {addingParameter}", con);
                            ds = new DataSet(); // Создаем объект класса DataSet
                            adap.Fill(ds, "Directory_readers");
                            foreach (DataRow dr in ds.Tables["Directory_readers"].Rows)
                            {
                                if (!listReturnDate.Contains((int)dr["id"]))
                                {
                                    string nameSubscriber = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                                    dgvHistoryR_CB.Rows.Add(dr["Дата_выдачи"].ToString().Split(' ')[0], dr["Дата_возврата"].ToString().Split(' ')[0],
                                        nameSubscriber);
                                }
                            }
                        //adap = new SqlDataAdapter($"SELECT * FROM Directory_readers JOIN Subscriber ON " +
                        //    $"Directory_readers.Абонент = Subscriber.id where Directory_readers.Экземпляр = {addingParameter}", con);
                        //ds = new DataSet(); // Создаем объект класса DataSet
                        //adap.Fill(ds, "Copy_book");
                        //foreach (DataRow dr in ds.Tables["Copy_book"].Rows)
                        //{
                        //    if (!listReturnDate.Contains((int)dr["id"]))
                        //    {
                        //        string nameSubscriber = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                        //        dgvHistoryR_CB.Rows.Add(dr["Дата_выдачи"].ToString().Split(' ')[0], dr["Дата_возврата"].ToString().Split(' ')[0],
                        //            nameSubscriber);
                        //    }
                        //}
                        adap = new SqlDataAdapter($"SELECT * FROM Copy_book JOIN Book ON Copy_book.Произведение = Book.id " +
                           $"JOIN Avtor ON Book.Автор = Avtor.id JOIN Directory_publishers ON" +
                           $" Copy_book.Издательство = Directory_publishers.id  where Copy_book.id = {addingParameter}", con);
                        ds = new DataSet(); // Создаем объект класса DataSet
                        adap.Fill(ds, "Copy_book");
                        foreach (DataRow dr in ds.Tables["Copy_book"].Rows)
                        {
                            rtbAddingInfCB.Text = $"Произведение:   {dr["Название"]}\nЖанр:   {dr["Жанр"]}\nОтдел:    {dr["Отдел"]}\n" +
                                $"Краткое описание:   {dr["Описание"]}\nАвтор:   " +
                                $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.\n\n" +
                                $"Издательство: {dr["Издательство1"]}\nГород: {dr["Место"]}\nГод издания: {dr["Год_издания"]}\n" +
                                $"Число страниц: {dr["Число_страниц"]}\nISBN: {dr["ISBN"]}\n";
                            pbImage.Image = byteArrayToImage((byte[])dr["Обложка"]);
                        }
                        con.Close();
                        break;
                    }
                case "Dir_ReadersB":
                    {
                        adap = new SqlDataAdapter($"SELECT * FROM Copy_book where Copy_book.Произведение = {addingParameter}", con);
                        ds = new DataSet(); // Создаем объект класса DataSet
                        adap.Fill(ds, "Copy_book");
                        foreach (DataRow item in ds.Tables["Copy_book"].Rows)
                        {
                            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers JOIN Subscriber ON " +
                            $"Directory_readers.Абонент = Subscriber.id where Directory_readers.Экземпляр = {item["id"]}", con);
                            adap.Fill(ds, $"Directory_readers{item["id"]}");
                            foreach (DataRow dr in ds.Tables[$"Directory_readers{item["id"]}"].Rows)
                            {
                                if (!listReturnDate.Contains((int)dr["id"])) 
                                { 
                                string nameSubscriber = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                                dgvHistoryR_B.Rows.Add(item["Инвентарный_номер"], dr["Дата_выдачи"].ToString().Split(' ')[0],
                                    dr["Дата_возврата"].ToString().Split(' ')[0], nameSubscriber);
                                }
                            }
                        }

                        con.Close();
                        break;
                    }
                    //case "Dir_Readers":
                    //    {
                    //        //foreach (var d in directories)
                    //        //{
                    //        //    foreach (var dr in dataDB.DirReaders)
                    //        //    {
                    //        //        if (dr == d)
                    //        //        {
                    //        //            string nameSubscriber = $"{dr.Subscriber.LastName} {dr.Subscriber.FirstName[0]}.{dr.Subscriber.MiddleName[0]}.";
                    //        //            dgvDirReaders.Rows.Add(dr.CopyBook.InventaryNumber, dr.DateIssue.ToString().Split(' ')[0],
                    //        //                dr.ReturnDate.ToString().Split(' ')[0], nameSubscriber, dr.CopyBook.Book.Name);
                    //        //        }
                    //        //    }
                    //        //}

                    //        foreach (var item in dates)
                    //        {
                    //            adap = new SqlDataAdapter($"SELECT * FROM Directory_readers JOIN Subscriber ON " +
                    //            $"Directory_readers.Абонент = Subscriber.id JOIN Copy_book ON " +
                    //            $"Directory_readers.Экземпляр = Copy_book.id JOIN Book ON " +
                    //            $"Copy_book.Произведение = Book.id where Directory_readers.id = {item}", con);
                    //            ds = new DataSet(); // Создаем объект класса DataSet
                    //            adap.Fill(ds, "Directory_readers");
                    //            foreach (DataRow dr in ds.Tables["Directory_readers"].Rows)
                    //            {
                    //                string nameSubscriber = $"{dr["Фамилия"]} {dr["Имя"].ToString()[0]}.{dr["Отчество"].ToString()[0]}.";
                    //                dgvDirReaders.Rows.Add(dr["Инвентарный_номер"], dr["Дата_выдачи"].ToString().Split(' ')[0],
                    //                        nameSubscriber, dr["Название"]);
                    //            }
                    //        }
                    //        con.Close();
                    //        break;
                    //    }
                    //case "Subscriber":
                    //    {
                    //        foreach (var s in dataDB.Subscribers)
                    //        {
                    //            dgvSubscriber.Rows.Add(s.id, s.LastName, s.FirstName, s.MiddleName, s.PhoneNumber,
                    //                s.RegistrationDate.ToString().Split(' ')[0], s.Street, s.House, s.Apartment);
                    //        }
                    //        break;
                    //    }
            }
        }
        public void ZeroGb()
        {
            gbCatalog.Visible = false;
            gbListBooks.Visible = false;
            bSaveCatalog.Visible = false;
        }


        private void bCatalog_Click(object sender, EventArgs e)
        {
            ZeroGb();
            gbCatalog.Visible = true;
        }
        fInsert insert = new fInsert();
        private void bInsertCB_Click(object sender, EventArgs e)
        {
            insert.NameTable = "CB";
            insert.Text = "Привоз";
            insert.Show();
        }

        private void dgvCatalog_CellToolTipTextChanged(object sender, DataGridViewCellEventArgs e)
        {
            bSaveCatalog.Visible = true;
        }
        public DataTable SelectTable(string nameTable)
        {
            adap = new SqlDataAdapter($"SELECT * FROM {nameTable}", con);
            dt = new DataTable();
            adap.Fill(dt);
            return dt;
        }
        private void bSaveCatalog_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            adap = new SqlDataAdapter($"SELECT * FROM Book JOIN Avtor ON Book.Автор = Avtor.id", con);
            dt = new DataTable();
            adap.Fill(dt);
            for (int i = 0; i < dgvCatalog.Rows.Count-1; i++)
            {
                string[] F_IO = dgvCatalog.Rows[i].Cells[5].Value.ToString().Split(' ');
                string[] IO = F_IO[1].Split('.');

                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["Фамилия"].ToString() == F_IO[0] && dr["Имя"].ToString()[0].ToString() == IO[0] 
                        && dr["Отчество"].ToString()[0].ToString() == IO[1])
                    {
                        command.CommandText = $"UPDATE Book SET Название = @Название, Жанр = @Жанр, Отдел = @Отд, " +
                            $"Описание = @Описание, Автор = @IdАвтор WHERE id = '{dgvCatalog.Rows[i].Cells[0].Value}'";
                        command.Connection = con;
                        command.Parameters.Clear();
                        command.Parameters.Add(new SqlParameter("@Название", dgvCatalog.Rows[i].Cells[1].Value));
                        command.Parameters.Add(new SqlParameter("@Жанр", dgvCatalog.Rows[i].Cells[2].Value));
                        command.Parameters.Add(new SqlParameter("@Отд", dgvCatalog.Rows[i].Cells[3].Value));
                        command.Parameters.Add(new SqlParameter("@Описание", dgvCatalog.Rows[i].Cells[4].Value));
                        command.Parameters.Add(new SqlParameter("@IdАвтор", dr["id1"]));
                        command.ExecuteNonQuery();
                    }
                }

                
            }
            MessageBox.Show("Изменения сохранены");
            con.Close();
            PresentJoinData("Book-Avtor");
            
        }

        private void dgvCatalog_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            bSaveCatalog.Visible = true;
            if (e.RowIndex == 3)
            {
                foreach (var item in insert.genreD)
                {
                    if (item.Genre == dgvCatalog.Rows[e.RowIndex].Cells[2].Value.ToString())
                    {
                        dgvCatalog.Rows[e.RowIndex].Cells[3].Value = item.Department;
                    }
                }
            }
        }

        private void bHistoryR_B_Click(object sender, EventArgs e)
        {
            pHistoryR_B.Visible = true;
        }

        private void dgvCatalog_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvHistoryR_B.Rows.Clear();
            PresentData("Dir_ReadersB", dgvCatalog.Rows[e.RowIndex].Cells[0].Value.ToString());
        }

        private void bClosePHistoryR_B_Click(object sender, EventArgs e)
        {
            pHistoryR_B.Visible = false;
        }

        private void bOpenForm2_Click(object sender, EventArgs e)
        {
            cards = new FCards();
            cards.NameCards = "CatalogCards";
            cards.Text = "Каталожные карты";
            cards.Show();
        }

        private void dgvCopyBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dgvHistoryR_CB.Rows.Clear();
                id_CopyBook = dgvCopyBook.Rows[e.RowIndex].Cells[0].Value.ToString();
                id_Book = dgvCopyBook.Rows[e.RowIndex].Cells[2].Value.ToString();
                id_DirPubl = dgvCopyBook.Rows[e.RowIndex].Cells[3].Value.ToString();
                PresentData("Dir_ReadersCB", id_CopyBook);
            }
        }

        private void bOpenPHistoryR_CB_Click(object sender, EventArgs e)
        {
            pHistoryR_CB.Visible = true;
        }

        private void bClosePHistoryR_CB_Click(object sender, EventArgs e)
        {
            pHistoryR_CB.Visible = false;
        }

        private void bChangeImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pbImage.Image = new Bitmap(openFileDialog.FileName);
                    byte[] image_byte = imageToByteArray(pbImage.Image);
                    con.Open();
                    SqlCommand command = new SqlCommand($"UPDATE Directory_publishers SET Обложка = @Image " +
                        $"WHERE Издательство = @PublHouse and Произведение = (select id from Book where Название = @Book)", con);
                    command.Parameters.Add(new SqlParameter("@image", image_byte));
                    command.Parameters.Add(new SqlParameter("@PublHouse", id_DirPubl));
                    command.Parameters.Add(new SqlParameter("@Book", id_Book));
                    command.ExecuteNonQuery();
                    con.Close();
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }
        }

        private void bSubscribers_Click(object sender, EventArgs e)
        {
            ZeroGb();
            gbSubscriber.Visible = true;
            PresentJoinData("Subscriber");
        }

        private void bOpenInsertSubs_Click(object sender, EventArgs e)
        {
            insert.NameTable = "S";
            insert.Text = "Добавление абонента";
            insert.Show();
        }

        private void bOpenSubsCards_Click(object sender, EventArgs e)
        {
            cards = new FCards();
            cards.NameCards = "SubsCards";
            cards.Text = "Абонементные карты";
            cards.Show();
        }
    }
}
