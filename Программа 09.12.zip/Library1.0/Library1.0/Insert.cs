﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library1._0
{
    /*обработка кнопок Yes No в Message
     повторное открытие формы добавления
    панель добавления книги: добавление автора и сохранение*/
    public partial class fInsert : Form
    {
        public string NameTable;
        public string addingPar;
        SqlConnection con = new SqlConnection("Server=WIN-76V4P6QRV5R\\SQLEXPRESS;" + "database=DB_library;" + "Integrated Security=True");
        SqlDataAdapter adap;
        DataSet ds;
        DataTable dt;
        fInsert insert;
        public GenreDepartment[] genreD = { new GenreDepartment("Басня","Б1"), new GenreDepartment("Баллада","Б2"),
            new GenreDepartment("Былины", "Б3"), new GenreDepartment("Видения","В1"), new GenreDepartment("Детектив","Д1"),
            new GenreDepartment("Очерк","О1"), new GenreDepartment("Ода", "О2"), new GenreDepartment("Комедия", "К1"),
            new GenreDepartment("Комедия нравов", "К2"), new GenreDepartment("Лирическое стихотворение(проза)", "П1"),
            new GenreDepartment("Миф", "М2"),new GenreDepartment("Научная фантастика", "Н1"), new GenreDepartment("Новелла", "Н2"),
            new GenreDepartment("Песня(Песнь)", "П2"),new GenreDepartment("Повесть", "П3"), new GenreDepartment("Поэма", "П4"),
            new GenreDepartment("Послание", "П5"),new GenreDepartment("Рассказ", "Р1"), new GenreDepartment("Роман", "Р2"),
            new GenreDepartment("Сказка", "С1"),new GenreDepartment("Трагедия", "Т1"), new GenreDepartment("Фольклор", "Ф1"),
            new GenreDepartment("Эпопея", "Э1"),new GenreDepartment("Элегия", "Э2"), new GenreDepartment("Эпиграмма", "Э3"),
            new GenreDepartment("Эпос", "Э4"), new GenreDepartment("Эссе", "Э5")};
        public struct GenreDepartment
        {
            public string Genre { get; set; }
            public string Department { get; set; }
            public GenreDepartment(string genre, string department)
            {
                Genre = genre;
                Department = department;
            }
        }
        public fInsert()
        {
            InitializeComponent();
            
        }
        public string[] DropDownList(DataTable dataTable, string nameCell)
        {
            string[] list = new string[dataTable.Rows.Count];
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                if (nameCell != "Полное имя")
                {
                    list[i] = dataTable.Rows[i][nameCell].ToString();
                }
                else
                {
                    list[i] = $"{dataTable.Rows[i]["Фамилия"]} {dataTable.Rows[i]["Имя"]} {dataTable.Rows[i]["Отчество"]} ";
                }
            }
            return list;
        }
        public void TBAutoComplete(TextBox textBox, string nameTable, string nameCell)
        {
            var source = new AutoCompleteStringCollection();
            source.AddRange(DropDownList(SelectTable(nameTable), nameCell));
            textBox.AutoCompleteCustomSource = source;
            textBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }
        public void ZeroP()
        {
            pInsertCB.Visible = false;
            pInsertB.Visible = false;
            pInsertPublH.Visible = false;
            bSave.Visible = true;
            bDelete.Visible = true;
        }
        private void Insert_Load(object sender, EventArgs e)
        {
            ZeroP();
            UpdateData();
            insert = new fInsert();
        }
        public void UpdateData()
        {
            switch (NameTable)
            {
                case "CB":
                    {
                        pInsertCB.Visible = true;
                        TBAutoComplete(tbNameBook, "Book", "Название");
                        TBAutoComplete(tbPublHouse, "Directory_publishers", "Издательство");
                        break;
                    }
                case "B":
                    {
                        pInsertB.Visible = true;
                        var source = new AutoCompleteStringCollection();
                        string[] genres = new string[genreD.Length];
                        for (int i = 0; i < genreD.Length; i++)
                        {
                            genres[i] = genreD[i].Genre;
                        }
                        source.AddRange(genres);
                        tbGenre.AutoCompleteCustomSource = source;
                        tbGenre.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        tbGenre.AutoCompleteSource = AutoCompleteSource.CustomSource;
                        
                        TBAutoComplete(tbAvtor, "Avtor", "Полное имя");
                        break;
                    }
                case "DR": 
                    {
                        pInsertPublH.Visible = true;
                        bSave.Visible = false;
                        bDelete.Visible = false;
                        bInsert.Visible = false;
                        TBAutoComplete(tbNamePublH, "Directory_publishers", "Издательство");
                        tbBookPH.Text = addingPar;
                        break;
                    }
                case "Av":
                    {
                        pInsertAvtor.Visible = true;
                        break;
                    }
            }
        }
        public DataTable SelectTable(string nameTable)
        {
            adap = new SqlDataAdapter($"SELECT * FROM {nameTable}", con);
            dt = new DataTable();
            adap.Fill(dt);
            return dt;
        }
        public bool СorrectnessСheck()
        {
            if (NameTable == "CB")
            {
                if (nudNumCopies.Value == 0 | tbNameBook.Text == "" | tbPublHouse.Text == "")
                {
                    MessageBox.Show("Заполните данные в полях \"Количество экземпляров\", \"Произведение\" и \"Издательство\"",
                        "Неполное заполнение данных", MessageBoxButtons.OK);
                    return false;
                }
                else return true;
            }
            else
            {
                if (NameTable == "B")
                {
                    if (tbBook.Text == "" | tbDepartment.Text == "" | tbGenre.Text == "" | tbAvtor.Text == "")
                    {
                        MessageBox.Show("Заполните данные в полях \"Произведение\", \"Жанр\", \"Отдел\" и \"Автор\"",
                            "Неполное заполнение данных", MessageBoxButtons.OK);
                        return false;
                    }
                    else return true;
                }
                else
                {
                    if (NameTable == "DR")
                    {
                        if (tbPlace.Text == "" | tbNamePublH.Text == "" | tbNumPage.Text == "" | tbYearPubl.Text == "" | tbPrice.Text == ""
                            | tbISBN.Text == "" | tbBookPH.Text == "" | pbImageBook.Image == null)
                        {
                            MessageBox.Show("Заполните данные в полях \"Издательство\", \"Место\", \"Год издания\", \"Число страниц\", " +
                                "\"Год издания\", \"Число страниц\" и \"Автор\"",
                                "Неполное заполнение данных", MessageBoxButtons.OK);
                            return false;
                        }
                        else return true;
                    }
                    else
                    {
                        if (NameTable == "Av")
                        {
                            if (tbFirstNameAv.Text == "" | tbSecondNameAv.Text == "" | tbMiddleNameAv.Text == "")
                            {
                                MessageBox.Show("Заполните данные в полях \"Фамилия\", \"Имя\" и \"Отчество\"",
                                    "Неполное заполнение данных", MessageBoxButtons.OK);
                                return false;
                            }
                            else return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            
        }
        private void bInsert_Click(object sender, EventArgs e)
        {
            if (СorrectnessСheck())
            {
                switch (NameTable)
                {
                    case "CB":
                        {
                            if (CheckIsBook(tbNameBook.Text, tbPublHouse.Text))
                            {
                                dgvCopy_book.Rows.Add(tbNameBook.Text, tbPublHouse.Text, nudNumCopies.Value);
                            }
                            else MessageBox.Show("Книги такого издательства нет в базе. Проверьте название Издательства или " +
                                "добавьте новые сведения", "Внимание!");
                            break;
                        }
                    case "B":
                        {
                            dgvBook.Rows.Add(tbBook.Text, tbGenre.Text, tbDepartment.Text, tbDiscription.Text, tbAvtor.Text);
                            break;
                        }
                }
                ZeroTB(pInsertCB);
                ZeroTB(pInsertB);
            }
        }

        private void bDelete_Click(object sender, EventArgs e)
        {
            switch (NameTable)
            {
                case "CB":
                    {
                        dgvCopy_book.Rows.Remove(dgvCopy_book.Rows[rowDelete]);
                        break;
                    }
                case "B":
                    {
                        dgvBook.Rows.Remove(dgvBook.Rows[rowDelete]);
                        break;
                    }
            }
        }
        int rowDelete;
        int idB_Insert = 0;
        int idDR_Insert = 0;
        private void dgvCopy_book_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //entryDelete = dgvCopy_book.Rows[e.RowIndex].Cells[0].Value.ToString();
            if (e.RowIndex >= 0)
            {
                rowDelete = e.RowIndex;
            }
        }
        public bool CheckExistanceDB(string nameTable, string addingPar)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            int id;
            switch (nameTable)
            {
                case "Book":
                    {
                        command = new SqlCommand($"Select count(id) from {nameTable} where Название = @addingPar", con);
                        id = 0;
                        command.Parameters.Add(new SqlParameter("@addingPar", addingPar));
                        id = (int)command.ExecuteScalar();
                        con.Close();
                        if (id != 0)
                        {
                            return true;
                        }
                        else return false;
                    }
                case "Directory_publishers":
                    {
                        command = new SqlCommand($"Select count(id) from {nameTable} where Издательство = @addingPar", con);
                        id = 0;
                        command.Parameters.Add(new SqlParameter("@addingPar", addingPar));
                        id = (int)command.ExecuteScalar();
                        con.Close();
                        if (id != 0)
                        {
                            return true;
                        }
                        else return false;
                    }
                default:
                    {
                        return false;
                    }
            }

        }
        public bool CheckIsBook(string NameBook, string NameDPubl)
        {
            idB_Insert = 0;
            idDR_Insert = 0;
            bool isBook = false;

            if (CheckExistanceDB("Book", NameBook))
            {

                con.Open();
                adap = new SqlDataAdapter($"SELECT * FROM Book", con);
                ds = new DataSet(); // Создаем объект класса DataSet
                adap.Fill(ds, "Book");
                foreach (DataRow item in ds.Tables["Book"].Rows)
                {
                    if (item["Название"].ToString() == NameBook)
                    {
                        idB_Insert = (int)item["id"];
                    }
                }
                con.Close();
                if (CheckExistanceDB("Directory_publishers", NameDPubl))
                {
                    con.Open();
                    adap = new SqlDataAdapter($"SELECT * FROM Directory_publishers", con);
                    adap.Fill(ds, "Dir_publishers");
                    isBook = false;
                    foreach (DataRow item in ds.Tables["Dir_publishers"].Rows)
                    {
                        if (idB_Insert == (int)item["Произведение"] && NameDPubl == item["Издательство"].ToString())
                        {
                            idDR_Insert = (int)item["id"];
                            isBook = true;
                        }
                    }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Книги такого издательства нет в базе!\nДобавьте сведения об издании в базу.", "Внимание!");
                    isBook = false;
                }
            }
            else
            {
                MessageBox.Show("Вы не можете добавить экземпляр книги, которой нет в базе!\nДобавьте книгу в базу.", "Внимание!");
                isBook = false;
            }
            return isBook;
        }

        private void bSave_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand();
            bool isBook = false;
            switch (NameTable)
            {
                case "CB":
                    {
                        for (int i = 0; i < dgvCopy_book.Rows.Count-1; i++)
                        {
                            if (CheckIsBook(dgvCopy_book.Rows[i].Cells[0].Value.ToString(), dgvCopy_book.Rows[i].Cells[1].Value.ToString()))
                            {
                                con.Open();
                                adap = new SqlDataAdapter($"SELECT * FROM Copy_book Where Произведение = {idB_Insert}", con);
                                //ds = new DataSet(); // Создаем объект класса DataSet
                                adap.Fill(ds, "Copy_book");
                                int max_invNum = 0;
                                foreach (DataRow row in ds.Tables["Copy_book"].Rows)
                                {
                                    string allInvNum = row["Инвентарный_номер"].ToString();
                                    int invNum = Convert.ToInt32(allInvNum.Remove(0, 1));
                                    if (max_invNum < invNum)
                                    {
                                        max_invNum = invNum;
                                    }
                                }
                                for (int j = 1; j <= Convert.ToInt32(dgvCopy_book.Rows[i].Cells[2].Value); j++)
                                {
                                    string inventaryNum = $"{idB_Insert}{max_invNum + j}";
                                    command.CommandText = $"INSERT INTO Copy_book (Инвентарный_номер, Произведение, Издательство) " +
                                    $"VALUES ({inventaryNum}, {idB_Insert}, {idDR_Insert})";
                                    command.Connection = con;
                                    command.ExecuteNonQuery();
                                }
                            }
                        }
                        


                        dgvCopy_book.Rows.Clear();
                        break;
                    }
                case "B":
                    {
                        for (int i = 0; i < dgvBook.Rows.Count-1; i++)
                        {
                            dt = SelectTable("Avtor");
                            con.Open();
                            string[] FIO = dgvBook.Rows[i].Cells[4].Value.ToString().Split(' ');
                            foreach (DataRow dr in dt.Rows)
                            {
                                if (dr["Фамилия"].ToString() == FIO[0] && dr["Имя"].ToString() == FIO[1] && dr["Отчество"].ToString() == FIO[2])
                                {
                                    command.CommandText = $"INSERT INTO Book (Название, Жанр, Отдел, Описание, Автор) " +
                                    $"VALUES (@name, @genre, @department, @disciption, @idAvtor)";
                                    command.Connection = con;
                                    command.Parameters.Add(new SqlParameter("@name", dgvBook.Rows[i].Cells[0].Value));
                                    command.Parameters.Add(new SqlParameter("@genre", dgvBook.Rows[i].Cells[1].Value));
                                    command.Parameters.Add(new SqlParameter("@department", dgvBook.Rows[i].Cells[2].Value));
                                    command.Parameters.Add(new SqlParameter("@disciption", dgvBook.Rows[i].Cells[3].Value));
                                    command.Parameters.Add(new SqlParameter("@idAvtor", dr["id"]));
                                    command.ExecuteNonQuery();
                                }
                            }
                        }
                        dgvBook.Rows.Clear();
                        break;
                    }
            }
            con.Close();
        }

        private void bInsertB_Click(object sender, EventArgs e)
        {
            insert.NameTable = "B";
            insert.FindForm().Text = "Добавить произведение";
            insert.Show();
        }

        private void cbGenre_SelectedValueChanged(object sender, EventArgs e)
        {
            
        }

        private void dgvBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowDelete = e.RowIndex;
            }
        }

        private void bInsertAv_Click(object sender, EventArgs e)
        {
            insert = new fInsert();
            insert.NameTable = "Av";
            insert.FindForm().Text = "Добавить автора";
            insert.Show();
        }

        private void tbGenre_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < genreD.Length; i++)
            {
                if (genreD[i].Genre == tbGenre.Text)
                {
                    tbDepartment.Text = genreD[i].Department;
                }
            }
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        private void bInsertDP_Click(object sender, EventArgs e)
        {
            if (CheckExistanceDB("Book", tbNameBook.Text))
            {
                insert = new fInsert();
                insert.NameTable = "DR";
                insert.addingPar = tbNameBook.Text;
                insert.FindForm().Text = "Добавить сведения об издательстве";
                insert.Show();
            }
            else MessageBox.Show("Такой книги нет в базе. Для добавления информации об издании добавьте книгу.", "Внимание!");
        }

        private void tbNamePublH_TextChanged(object sender, EventArgs e)
        {
            adap = new SqlDataAdapter($"SELECT Место, Издательство FROM Directory_publishers", con);
            ds = new DataSet(); // Создаем объект класса DataSet
            adap.Fill(ds, "Directory_publishers");
            foreach (DataRow item in ds.Tables["Directory_publishers"].Rows)
            {
                if(tbNamePublH.Text == item["Издательство"].ToString())
                {
                    tbPlace.Text = item["Место"].ToString();
                    tbPlace.ReadOnly = true;
                }
                else
                {
                    tbPlace.ReadOnly = false;
                    tbPlace.Text = "";
                }
            }
        }

        private void bClearTBpPH_Click(object sender, EventArgs e)
        {
            ZeroTB(pInsertPublH);
            pbImageBook.Image = null;
        }
        private void bLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pbImageBook.Image = new Bitmap(openFileDialog.FileName);
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                    $"Details:\n\n{ex.StackTrace}");
                }
            }
        }

        private void bInsertDPubl_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand();
            command.CommandText = $"Select id from Book where Название = @addingPar";
            command.Parameters.Add(new SqlParameter("@addingPar", addingPar));
            command.Connection = con;
            int id_Book = Convert.ToInt32(command.ExecuteScalar());
            command.CommandText = $"INSERT INTO Directory_publishers (Место, Издательство, Год_издания, Число_копий," +
                $"Число_страниц, Обложка, ISBN, Цена, Произведение) VALUES (@Place, @PublHouse, @Year, {0}, @Num_page, " +
                $"@Image, @ISBN, @Price, @Book)";
            ImageConverter _imageConverter = new ImageConverter();
            byte[] xByte = (byte[])_imageConverter.ConvertTo(pbImageBook.Image, typeof(byte[]));
            command.Parameters.Add(new SqlParameter("@Place", tbPlace.Text));
            command.Parameters.Add(new SqlParameter("@PublHouse", tbNamePublH.Text));
            command.Parameters.Add(new SqlParameter("@Year", tbYearPubl.Text));
            command.Parameters.Add(new SqlParameter("@Num_page", tbNumPage.Text));
            command.Parameters.Add(new SqlParameter("@Image", xByte));
            command.Parameters.Add(new SqlParameter("@ISBN", tbISBN.Text));
            command.Parameters.Add(new SqlParameter("@Price", tbPrice.Text));
            command.Parameters.Add(new SqlParameter("@Book", id_Book));
            command.Connection = con;
            command.ExecuteNonQuery();
            con.Close();
            ZeroTB(pInsertPublH);
            pbImageBook.Image = null;
        }

        private void bInsertAvtor_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand command = new SqlCommand($"insert into Avtor (Фамилия, Имя, Отчество) values (@FirstName, @SecondName, @MiddleName)",
                con);
            command.Parameters.Add(new SqlParameter("@FirstName", tbFirstNameAv.Text));
            command.Parameters.Add(new SqlParameter("@SecondName", tbSecondNameAv.Text));
            command.Parameters.Add(new SqlParameter("@MiddleName", tbMiddleNameAv.Text));
            command.ExecuteNonQuery();
            con.Close();
            ZeroTB(pInsertAvtor);
        }
        public void ZeroTB(Panel panel)
        {
            foreach (Control item in panel.Controls)
            {
                if (item.Name[0] == 't' && item.Name[1] == 'b')
                {
                    item.Text = " ";
                }
            }
        }
    }
}
