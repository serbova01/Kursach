﻿namespace Library1._0
{
    partial class FCards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lbListSubscribers = new System.Windows.Forms.ListBox();
            this.lbListBooks = new System.Windows.Forms.ListBox();
            this.bSaveFile = new System.Windows.Forms.Button();
            this.rtbCatalogCard = new System.Windows.Forms.RichTextBox();
            this.sfdCatalogCards = new System.Windows.Forms.SaveFileDialog();
            this.pSubsInfomation = new System.Windows.Forms.Panel();
            this.dgvSubsCard = new System.Windows.Forms.DataGridView();
            this.DateReturn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InventaryNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name_and_AvtorBook = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pSubsInfomation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubsCard)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lbListSubscribers);
            this.splitContainer1.Panel1.Controls.Add(this.lbListBooks);
            this.splitContainer1.Panel1MinSize = 150;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pSubsInfomation);
            this.splitContainer1.Panel2.Controls.Add(this.bSaveFile);
            this.splitContainer1.Panel2.Controls.Add(this.rtbCatalogCard);
            this.splitContainer1.Size = new System.Drawing.Size(887, 450);
            this.splitContainer1.SplitterDistance = 241;
            this.splitContainer1.TabIndex = 0;
            // 
            // lbListSubscribers
            // 
            this.lbListSubscribers.FormattingEnabled = true;
            this.lbListSubscribers.ItemHeight = 16;
            this.lbListSubscribers.Location = new System.Drawing.Point(3, 7);
            this.lbListSubscribers.Name = "lbListSubscribers";
            this.lbListSubscribers.Size = new System.Drawing.Size(237, 420);
            this.lbListSubscribers.TabIndex = 1;
            this.lbListSubscribers.SelectedIndexChanged += new System.EventHandler(this.lbListSubscribers_SelectedIndexChanged);
            // 
            // lbListBooks
            // 
            this.lbListBooks.FormattingEnabled = true;
            this.lbListBooks.ItemHeight = 16;
            this.lbListBooks.Location = new System.Drawing.Point(3, 7);
            this.lbListBooks.Name = "lbListBooks";
            this.lbListBooks.Size = new System.Drawing.Size(237, 420);
            this.lbListBooks.TabIndex = 0;
            this.lbListBooks.SelectedIndexChanged += new System.EventHandler(this.lbListBooks_SelectedIndexChanged);
            // 
            // bSaveFile
            // 
            this.bSaveFile.Location = new System.Drawing.Point(222, 397);
            this.bSaveFile.Name = "bSaveFile";
            this.bSaveFile.Size = new System.Drawing.Size(158, 41);
            this.bSaveFile.TabIndex = 1;
            this.bSaveFile.Text = "Сохранить в файл";
            this.bSaveFile.UseVisualStyleBackColor = true;
            this.bSaveFile.Click += new System.EventHandler(this.bSaveFile_Click);
            // 
            // rtbCatalogCard
            // 
            this.rtbCatalogCard.BulletIndent = 1;
            this.rtbCatalogCard.Location = new System.Drawing.Point(15, 13);
            this.rtbCatalogCard.Name = "rtbCatalogCard";
            this.rtbCatalogCard.ReadOnly = true;
            this.rtbCatalogCard.Size = new System.Drawing.Size(503, 278);
            this.rtbCatalogCard.TabIndex = 0;
            this.rtbCatalogCard.Text = "";
            this.rtbCatalogCard.Visible = false;
            // 
            // pSubsInfomation
            // 
            this.pSubsInfomation.Controls.Add(this.dgvSubsCard);
            this.pSubsInfomation.Location = new System.Drawing.Point(3, 4);
            this.pSubsInfomation.Name = "pSubsInfomation";
            this.pSubsInfomation.Size = new System.Drawing.Size(639, 387);
            this.pSubsInfomation.TabIndex = 2;
            // 
            // dgvSubsCard
            // 
            this.dgvSubsCard.BackgroundColor = System.Drawing.Color.Plum;
            this.dgvSubsCard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSubsCard.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DateReturn,
            this.InventaryNum,
            this.Department,
            this.Name_and_AvtorBook});
            this.dgvSubsCard.Location = new System.Drawing.Point(3, 3);
            this.dgvSubsCard.Name = "dgvSubsCard";
            this.dgvSubsCard.RowHeadersWidth = 51;
            this.dgvSubsCard.RowTemplate.Height = 24;
            this.dgvSubsCard.Size = new System.Drawing.Size(633, 381);
            this.dgvSubsCard.TabIndex = 0;
            // 
            // DateReturn
            // 
            this.DateReturn.HeaderText = "Дата возврата";
            this.DateReturn.MinimumWidth = 6;
            this.DateReturn.Name = "DateReturn";
            this.DateReturn.Width = 125;
            // 
            // InventaryNum
            // 
            this.InventaryNum.HeaderText = "Инвентарный номер";
            this.InventaryNum.MinimumWidth = 6;
            this.InventaryNum.Name = "InventaryNum";
            this.InventaryNum.Width = 125;
            // 
            // Department
            // 
            this.Department.HeaderText = "Отдел";
            this.Department.MinimumWidth = 6;
            this.Department.Name = "Department";
            this.Department.Width = 70;
            // 
            // Name_and_AvtorBook
            // 
            this.Name_and_AvtorBook.HeaderText = "Название и имя автора книги";
            this.Name_and_AvtorBook.MinimumWidth = 6;
            this.Name_and_AvtorBook.Name = "Name_and_AvtorBook";
            this.Name_and_AvtorBook.Width = 250;
            // 
            // FCards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(887, 450);
            this.Controls.Add(this.splitContainer1);
            this.Name = "FCards";
            this.Text = "Каталожные карточки";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.FCards_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.pSubsInfomation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSubsCard)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox lbListBooks;
        private System.Windows.Forms.RichTextBox rtbCatalogCard;
        private System.Windows.Forms.Button bSaveFile;
        private System.Windows.Forms.SaveFileDialog sfdCatalogCards;
        private System.Windows.Forms.ListBox lbListSubscribers;
        private System.Windows.Forms.Panel pSubsInfomation;
        private System.Windows.Forms.DataGridView dgvSubsCard;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateReturn;
        private System.Windows.Forms.DataGridViewTextBoxColumn InventaryNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name_and_AvtorBook;
    }
}